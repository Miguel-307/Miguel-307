<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Shippers</title>
    <style>
        body {
            background-color: #0e0e10;
            color: #f5f6fa;
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 30px;
        }
        form {
            background-color: #1e1e22;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px #00a8ff;
            width: 300px;
            margin: 20px auto;
        }
        input, button {
            width: 100%;
            margin: 8px 0;
            padding: 8px;
            border-radius: 5px;
            border: none;
        }
        button {
            background-color: #00a8ff;
            color: white;
            cursor: pointer;
        }
        a {
            color: #00a8ff;
            text-decoration: none;
        }
        table {
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #f5f6fa;
            padding: 6px 10px;
        }
        th {
            background-color: #00a8ff;
        }
    </style>
</head>
<body>

<h2>Conexión con MySQL</h2>

<?php
require_once "conexion.php";
require_once "funciones.php";

// Si el usuario pulsa “Volver”, limpiamos el POST
if (isset($_POST['volver'])) {
    unset($_POST['conectar']);
}

// Conectamos
$conexion = conectar();

// Si la conexión fue exitosa, mostramos la tabla
if ($conexion) {
    $shippers = cargar_shippers($conexion);
    echo mostrar_tabla($shippers);
}
?>

</body>
</html>
