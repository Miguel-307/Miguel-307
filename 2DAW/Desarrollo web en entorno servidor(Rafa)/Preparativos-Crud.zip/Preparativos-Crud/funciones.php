<?php
/* -----------------------------
   MODIFICAR UN SHIPPER
----------------------------- */
function modificar($conexion, $id, $nombre, $telef){
    $sql = "UPDATE shipper 
            SET companyName = '".$nombre."', 
                phone = '".$telef."' 
            WHERE shipperId = ".$id;

    $res = $conexion->query($sql);

    if(!$res) {
        return false;
    }
    return true;   
}

/* -----------------------------
   CARGAR UN SHIPPER POR ID
----------------------------- */
function cargarId($conexion, $id) {
    $sql = "SELECT * FROM shipper WHERE shipperId = ".$id;
    $res = $conexion->query($sql);
    return $res;
}

/* -----------------------------
   INSERTAR NUEVO SHIPPER
----------------------------- */
function insertar($conexion, $nombre, $telef) {
    $sql = "INSERT INTO shipper (companyName, phone) 
            VALUES ('".$nombre."', '".$telef."')";
    $res = $conexion->query($sql);

    if(!$res) {
        return false;
    }
    return true;
}

/* -----------------------------
   BORRAR UN SHIPPER
----------------------------- */
function borrar($conexion, $id) {
    $sql = "DELETE FROM shipper WHERE shipperId = ".$id;
    $res = $conexion->query($sql);

    if(!$res) {
        return false;
    }
    return true;
}

/* -----------------------------
   CARGAR TODOS LOS SHIPPERS
----------------------------- */
function cargar_shippers($conexion) {
    $sql = "SELECT * FROM shipper";
    $res = $conexion->query($sql);

    if(!$res) {
        return null;
    }
    return $res;
}

/* -----------------------------
   MOSTRAR TABLA SHIPPERS
----------------------------- */
function mostrar_tabla($datos) {
    $res = "";

    if($datos && $datos->rowCount() > 0) {
        $res .= "<h3 style='color:#00a8ff;'>TABLA SHIPPERS</h3>";
        $res .= "<table border='1' cellpadding='5' cellspacing='0'>";
        $res .= "<tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Modificar</th>
                    <th>Borrar</th>
                </tr>";

        // Se recorre por nombres de columna en lugar de índices numéricos
        foreach($datos as $sh) {
            $res .= "<tr>
                        <td>".$sh['shipperId']."</td>
                        <td>".$sh['companyName']."</td>
                        <td>".$sh['phone']."</td>
                        <td><a href='formulariomodificar.php?id=".$sh['shipperId']."' style='color:#00a8ff;'>Modificar</a></td>
                        <td><a href='borrar.php?id=".$sh['shipperId']."' style='color:#ff5555;'>Borrar</a></td>
                     </tr>";
        }

        $res .= "</table><br>";
        $res .= "<a href='formularioinsertar.php' style='color:#00ff88;'>Nuevo registro</a>";
    } else {
        $res = "<p>No hay datos para mostrar.</p>";
    }

    return $res;
}
?>
