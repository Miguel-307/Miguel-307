<?php
function conectar() {
    // Si aún no se ha enviado el formulario
    if (!isset($_POST['conectar'])) {
        echo '
        <form method="post" action="">
            <label>Servidor:</label>
            <input type="text" name="servidor" value="localhost" required><br>

            <label>Base de datos:</label>
            <input type="text" name="bd" required><br>

            <label>Usuario:</label>
            <input type="text" name="usuario" value="root" required><br>

            <label>Contraseña:</label>
            <input type="password" name="clave"><br><br>

            <button type="submit" name="conectar">Conectar</button>
        </form>
        ';
        return null;
    } else {
        // Si el usuario ya envió el formulario, conectamos
        $servidor = $_POST['servidor'];
        $bd = $_POST['bd'];
        $usuario = $_POST['usuario'];
        $clave = $_POST['clave'];

        try {
            $conexion = new PDO("mysql:host=$servidor;dbname=$bd;charset=utf8", $usuario, $clave);
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            echo "<p style='color: #00ff88;'>✅ Conexión exitosa con la base de datos '$bd'.</p>";
            echo "<form method='post' action=''>
                    <button type='submit' name='volver' style='background:#00a8ff;color:white;padding:8px 15px;border:none;border-radius:5px;cursor:pointer;'>🔙 Volver al formulario</button>
                  </form>";
            return $conexion;
        } catch (PDOException $e) {
            echo "<p style='color:red;'>❌ Error: ".$e->getMessage()."</p>";
            echo "<form method='post' action=''>
                    <button type='submit' name='volver' style='background:#00a8ff;color:white;padding:8px 15px;border:none;border-radius:5px;cursor:pointer;'>🔙 Volver al formulario</button>
                  </form>";
            return null;
        }
    }
}
?>
