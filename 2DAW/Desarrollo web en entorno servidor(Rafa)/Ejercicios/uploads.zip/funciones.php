<?php // public/funciones.php
declare(strict_types=1);
// opcional si quieres reutilizar HTML
?>
<h2>Funciones en PHP</h2>

<article>
  <h3>Con parámetros y return</h3>
  <pre><?php
function sumar(int $a, int $b): int {
  return $a + $b;
}
echo "sumar(3, 5) = ".sumar(3,5); // 8
?></pre>
</article>

<article>
  <h3>Función anónima</h3>
  <pre><?php
$porDos = function (int $n): int { return $n * 2; };
echo $porDos(7); // 14
?></pre>
</article>

<article>
  <h3>Uso de variables externas (closures) con <code>use</code></h3>
  <pre><?php
$factor = 3;
$multiplicar = function (int $n) use ($factor): int {
  return $n * $factor; // captura $factor del ámbito externo
};
echo $multiplicar(4); // 12
?></pre>
</article>

<article>
  <h3>Variables estáticas dentro de funciones</h3>
  <pre><?php
function contador(): int {
  static $c = 0; // se conserva entre llamadas
  return ++$c;
}
echo contador()." ".contador()." ".contador(); // 1 2 3
?></pre>
</article>

<p><a href="index.php">Volver</a></p>
