<?php // public/upload.php
declare(strict_types=1);
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Subir ficheros</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Subida de archivos</h1></header><section>

<article>
  <h3>Formulario</h3>
  <form action="upload.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="archivo" required>
    <button>Subir</button>
  </form>
</article>

<article>
<?php
$uploadsDir = __DIR__.'/uploads';
if (!is_dir($uploadsDir)) { mkdir($uploadsDir, 0777, true); }

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_FILES['archivo'])) {
  $f = $_FILES['archivo'];
  if ($f['error'] === UPLOAD_ERR_OK) {
    // Validar tamaño (ej: max 2MB)
    $maxBytes = 2*1024*1024;
    if ($f['size'] > $maxBytes) {
      echo "<p>El archivo excede 2MB.</p>";
    } else {
      $nombreSeguro = preg_replace('/[^A-Za-z0-9._-]/','_', $f['name']);
      $destino = $uploadsDir . '/' . $nombreSeguro;
      if (move_uploaded_file($f['tmp_name'], $destino)) {
        echo "<p>Subido correctamente: <strong>".htmlspecialchars($nombreSeguro)."</strong></p>";
        echo "<ul>";
        echo "<li>Tamaño (bytes): ".filesize($destino)."</li>";
        echo "<li>SHA1 (contenido): ".sha1_file($destino)."</li>";
        // sha1() para un string:
        $cadena = "hola";
        echo "<li>SHA1 de 'hola' (sha1()): ".sha1($cadena)."</li>";
        echo "</ul>";
        echo '<p><a href="borrar.php?f='.urlencode($nombreSeguro).'">Borrar este archivo</a></p>';
      } else {
        echo "<p>Error al mover el archivo.</p>";
      }
    }
  } else {
    echo "<p>Error en la subida (código {$f['error']}).</p>";
  }
}
?>
</article>

<p><a href="index.php">Volver</a></p>
</section></body></html>
