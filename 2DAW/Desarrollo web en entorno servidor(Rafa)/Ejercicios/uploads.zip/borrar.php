<?php // public/borrar.php
declare(strict_types=1);
$uploadsDir = __DIR__.'/uploads';
$ok = false;

if (!empty($_GET['f'])) {
  $nombreSeguro = preg_replace('/[^A-Za-z0-9._-]/','_', $_GET['f']);
  $ruta = $uploadsDir.'/'.$nombreSeguro;
  if (str_starts_with(realpath($ruta) ?: '', realpath($uploadsDir)) && is_file($ruta)) {
    $ok = unlink($ruta);
  }
}
?><!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Borrar archivo</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Borrar archivo</h1></header><section>
<p><?= $ok ? "Archivo borrado." : "No se pudo borrar." ?></p>
<p><a href="upload.php">Volver</a></p>
</section></body></html>
