<?php // public/mail_plain.php
declare(strict_types=1);
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Email texto plano</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Enviar email (texto plano)</h1></header><section>

<article>
<form method="POST">
  <label>Para: <input type="email" name="to" required></label>
  <label>Asunto: <input name="subject" required></label>
  <label>Mensaje: <textarea name="message" required></textarea></label>
  <button>Enviar con mail()</button>
</form>
</article>

<article>
<?php
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $to = $_POST['to'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];
  $headers = "From: no-reply@tu-dominio.es\r\n";
  // OJO: mail() requiere que el servidor tenga un MTA configurado
  $ok = @mail($to, $subject, $message, $headers);
  echo $ok ? "<p>Enviado (si tu servidor está configurado).</p>" : "<p>Error al enviar.</p>";
}
?>
</article>

<details>
  <summary>Configurar SMTP del servidor</summary>
  <p>En hosting compartido normalmente ya está configurado. En servidores propios, configura un agente MTA (Postfix/Exim) o usa PHPMailer con SMTP autenticado.</p>
</details>

<p><a href="index.php">Volver</a></p>
</section></body></html>
