<?php // public/sesiones_login.php
declare(strict_types=1);
session_start(); // imprescindible para usar $_SESSION
$mensaje = '';

if (isset($_POST['accion'])) {
  if ($_POST['accion']==='login') {
    // DEMO: usuario/clave fijos (no en producción). Usa BD + password_hash en app real.
    $user = $_POST['user'] ?? '';
    $pass = $_POST['pass'] ?? '';
    if ($user === 'admin' && $pass === '1234') {
      $_SESSION['usuario'] = $user;
      $_SESSION['rol'] = 'admin';
      $mensaje = 'Login correcto.';
    } else {
      $mensaje = 'Credenciales inválidas.';
    }
  } elseif ($_POST['accion']==='mod') {
    if (isset($_SESSION['usuario'])) {
      $_SESSION['ultimo_acceso'] = date('c');
      $mensaje = 'Sesión modificada (ultimo_acceso).';
    } else {
      $mensaje = 'No hay sesión iniciada.';
    }
  } elseif ($_POST['accion']==='logout') {
    session_unset();        // limpia variables
    session_destroy();      // destruye sesión
    $mensaje = 'Sesión cerrada.';
  }
}
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Sesiones y Login</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Sesiones + Login</h1></header><section>

<article>
  <h3>Estado</h3>
  <pre><?php print_r($_SESSION); ?></pre>
  <p style="color:green"><?= htmlspecialchars($mensaje) ?></p>
</article>

<article>
  <h3>Login</h3>
  <form method="POST">
    <input type="hidden" name="accion" value="login">
    <label>Usuario: <input name="user" required></label>
    <label>Clave: <input type="password" name="pass" required></label>
    <button>Entrar</button>
  </form>
  <p><a href="protegido.php">Ir a página protegida</a></p>
</article>

<article>
  <h3>Modificar dato de sesión</h3>
  <form method="POST">
    <input type="hidden" name="accion" value="mod">
    <button>Marcar último acceso</button>
  </form>
</article>

<article>
  <h3>Logout</h3>
  <form method="POST">
    <input type="hidden" name="accion" value="logout">
    <button>Salir</button>
  </form>
</article>

<p><a href="index.php">Volver</a></p>
</section></body></html>
