<?php // public/mail_html_phpmailer.php
declare(strict_types=1);
require __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>PHPMailer</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Email HTML con PHPMailer (SMTP)</h1></header><section>

<article>
<form method="POST">
  <label>Para: <input type="email" name="to" required></label>
  <label>Asunto: <input name="subject" required></label>
  <label>HTML: <textarea name="html" required><h2>Hola</h2><p>Esto es <strong>HTML</strong>.</p></textarea></label>
  <button>Enviar con PHPMailer</button>
</form>
</article>

<article>
<?php
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $to = $_POST['to'];
  $subject = $_POST['subject'];
  $html = $_POST['html'];

  $mail = new PHPMailer(true);
  try {
    // SMTP
    $mail->isSMTP();
    $mail->Host       = 'smtp.tu-proveedor.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'usuario@tu-dominio.es';
    $mail->Password   = 'tu-contraseña';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // o PHPMailer::ENCRYPTION_SMTPS
    $mail->Port       = 587; // 465 para SMTPS

    // Remitente y destinatario
    $mail->setFrom('no-reply@tu-dominio.es', 'Tu App');
    $mail->addAddress($to);

    // Contenido
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $html;
    $mail->AltBody = strip_tags($html); // versión texto plano

    $mail->send();
    echo "<p>Correo enviado correctamente.</p>";
  } catch (Exception $e) {
    echo "<p>Error: {$mail->ErrorInfo}</p>";
  }
}
?>
</article>

<p><a href="index.php">Volver</a></p>
</section></body></html>
