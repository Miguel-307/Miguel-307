<?php // public/poo.php
declare(strict_types=1);
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>POO</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Programación Orientada a Objetos</h1></header><section><article>
<pre><?php
class Vehiculo {
  // visibilidad: public / protected / private
  public string $marca;
  protected int $velocidad = 0;
  private string $vin;

  public function __construct(string $marca, string $vin) {
    $this->marca = $marca;
    $this->vin = $vin;
  }

  public function acelerar(int $kmh): void {
    $this->velocidad += $kmh;
  }

  public function getVelocidad(): int {
    return $this->velocidad;
  }

  protected function infoPrivada(): string {
    return "VIN: ".$this->vin;
  }
}

class Coche extends Vehiculo {
  public function turbo(): void {
    $this->velocidad += 30; // OK: protected
  }
  public function datos(): string {
    // $this->vin  // NO: private no es accesible
    return "Marca: {$this->marca}, Velocidad: {$this->velocidad}";
  }
}

$miCoche = new Coche('Hyundai', 'VIN123');
$miCoche->acelerar(20);
$miCoche->turbo();
echo $miCoche->datos(); // Marca: Hyundai, Velocidad: 50
?></pre>
</article>
<p><a href="index.php">Volver</a></p>
</section></body></html>
