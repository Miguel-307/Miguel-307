<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
// Variables , estas variables solo con poner el numbre y el valor que tienen ya se declaran el tipo 
$numero=5; //entero
$decimal=5.5; //decimal
$texto="Hola mundo"; //cadena de texto
$booleano=true; //booleano
// Constantes, se definen con la palabra reservada define y no pueden cambiar su valor
define("PI",3.14);

// operaciones que se pueden hacer 
/*$mi_variable = 7;
$a = $b + $c;
$valor++;
$x += 5;
$y *= 2;
$z -= 3;
$w /= 4;*/




// La expresión $x == false es cierta (devuelve true).
// Sin embargo, $x === false no es cierta (devuelve false) pues $x es de tipo entero, no booleano.
//funciones no cogen valores de fuera a no ser que las conviertas en global dentro de ellas

$a = 1;
function prueba()
{
 global $a;
 $b = $a;
 // En este caso se le asigna a $b el valor 1
}
//para de clarar valores que a ir cambiando es con la palabra static
function contador()
{
 static $a=0;
 $a++;
 // Cada vez que se ejecuta la función, se incrementa el valor de $a
}
//poniendo "echo" se muestra en pantalla
echo "El valor de PI es: " . PI;

// esto te sirve para concadenar 
     echo "<br>".'John Lennon' . ' y ' . 'Paul McCartney';

 //para variables constantes o directamente const
    define('GRAVEDAD', 9.8);
    const gravedad = 9.8;//lo puse en minuscula para que no se repita 




//arrays 
$semana = [
    'Lunes',
    'Martes',
    'Miércoles',
    'Jueves',
    'Viernes',
    'Sábado',
    'Domingo'
];
echo "<br>".$semana[2]."<br>"; // Muestra "Miércoles"
//esto es para ver todo el contenido del array y se puede poner cualquier tipo de valor 
var_dump($semana);

// Array de partida
$planetas = ['Marte', 'Tierra', 'Venus'];

// Añadimos 'Mercurio'
$nuevosPlanetas = array_merge($planetas, ['Mercurio']);


//para saber  cuantos elementos tiene un array
echo count($planetas);

//para modificar 
$planetas[2] = 'Saturno';
echo "<br>" ;
var_dump($planetas);
//para borrar 
unset($planetas[1]);


//strings
$palabra = 'abcdef';
echo $palabra[2];
// c

$palabra2 = 'abcdef';
$palabra2[2] = 'Z';
echo "<br>".$palabra2;
// abZdef






//string===>array
$frase = 'En un lugar de la mancha';
$arrayDeFrase = preg_split('/[\s,]+/', $frase);
echo $arrayDeFrase[2];
// "lugar"
var_dump($arrayDeFrase);
/*
array(6) {
  [0] =>
  string(2) "En"
  [1] =>
  string(2) "un"
  [2] =>
  string(5) "lugar"
  [3] =>
  string(2) "de"
  [4] =>
  string(2) "la"
  [5] =>
  string(6) "mancha"
}
*/


//los diccionarios son como los mpas añades un valor y una clave
$empleados = [
    'Juan' => 34,
    'Luisa' => 56
];
echo $empleados['Luisa'];
//añadir en el diccionario
$empleados = [];
$empleados['Manolo'] = 99;
//modificar
$empleados['Manolo'] = 11;

//eliminar
unset($empleados['Manolo']);

//dos dimensiones
$zara = [
    123 => [
      'nombre' => 'Camisa a cuadros',
      'precio' => 29.95,
      'sexo' => 'Hombre'
    ],
    234 => [
      'nombre' => 'Falda manga',
      'precio' => 19.95,
      'sexo' => 'Mujer'
    ],
    345 => [
      'nombre' => 'Bolso minúsculo',
      'precio' => 50,
      'sexo' => 'Mujer'
    ]
];
echo $zara[345]['nombre'];
// Bolso minúsculo
//forrch dimensional
foreach ($zara as $producto) {
    foreach ($producto as $elemento) {
        echo "$elemento \n";
    }
}



//bucles
//foreach
$animalesFantasticos = ['fénix', 'dragón', 'grifo', 'pegaso', 'cerbero'];
foreach ($animalesFantasticos as $animal) {
    echo $animal . ' ';
} 
// fénix dragón grifo pegaso cerbero

//foreach con clave y valor
$animalesFantasticos = ['fénix', 'dragón', 'grifo', 'pegaso', 'cerbero'];
foreach ($animalesFantasticos as $posicion => $animal) {
    echo "El animal $animal ocupa la posición $posicion \n <br>";
}
// El animal fénix ocupa la posición 0 
// El animal dragón ocupa la posición 1 
// El animal grifo ocupa la posición 2 
// El animal pegaso ocupa la posición 3 
// El animal cerbero ocupa la posición 4 

//range() crea un array de elementos en un rango
//inicio,fin,y los saltos
var_dump(range(10, 15,1));



//for
for ($i = 0; $i < 10; $i++) {
    echo "$i \n";
}
// 0
// 1
// 2
// 3
// 4
// 5
// 6
// 7
// 8
// 9

//while
$i = 1;
while ($i < 10) {
    echo $i++;
}
// 123456789

//do while
$i = 1;
do {
    echo $i++;
} while ($i < 10);
// 123456789

//if
echo "Inicio \n";
if (2 > 0) {
    echo "Entro en el condicional \n";
}
echo 'Fin';
// Inicio
// Entro en el condicional
// Fin
if ('Ghibli' == 'Ghibli') {
    echo 'Bienvenido';
} else {
    echo 'No eres bien recibido'
}
// Bienvenido
$num = 1;
if ($num == 0) {
    echo "num es igual a 0";
} elseif ($num == 1) {
    echo "num es igual a 1";
} elseif ($num == 2) {
    echo "num es igual a 2";
} else {
    echo "No se a que es igual";
}
// num es igual a 1

switch ($num) {
    case 0:
        echo "num es igual a 0";
        break;
    case 1:
        echo "num es igual a 1";
        break;
    case 2:
        echo "num es igual a 2";
        break;
    default:
        echo "No se a que es igual";
        break;
}
// num es igual a 1
if (str_contains('La duda es uno de los nombres de la inteligencia', 'duda')) {
    // Entra
}
if (str_starts_with('La duda es uno de los nombres de la inteligencia', 'La duda es')) {
    // Entra
}
if (str_end_with('La duda es uno de los nombres de la inteligencia', 'inteligencia')) {
    // Entra
}


?>

</body>
</html>