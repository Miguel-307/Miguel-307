<?php // public/cookies.php
declare(strict_types=1);
$mensaje = '';

if ($_SERVER['REQUEST_METHOD']==='POST') {
  $accion = $_POST['accion'] ?? '';
  if ($accion==='crear') {
    setcookie('mi_cookie', $_POST['valor'] ?? 'valor', time()+3600, '/'); // 1h
    $mensaje = 'Cookie creada/actualizada (recarga para verla).';
  } elseif ($accion==='borrar') {
    setcookie('mi_cookie', '', time()-3600, '/'); // expirada
    $mensaje = 'Cookie borrada (recarga para confirmar).';
  }
}
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Cookies</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Cookies</h1></header><section>

<p><strong>Valor actual:</strong> <?= isset($_COOKIE['mi_cookie']) ? htmlspecialchars($_COOKIE['mi_cookie']) : '(no existe)' ?></p>
<p style="color:green"><?= htmlspecialchars($mensaje) ?></p>

<article>
  <h3>Crear/Actualizar</h3>
  <form method="POST">
    <input type="hidden" name="accion" value="crear">
    <label>Valor: <input name="valor" placeholder="ej. Miguel"></label>
    <button>Guardar cookie</button>
  </form>
</article>

<article>
  <h3>Borrar</h3>
  <form method="POST">
    <input type="hidden" name="accion" value="borrar">
    <button>Eliminar cookie</button>
  </form>
</article>

<p><a href="index.php">Volver</a></p>
</section></body></html>
