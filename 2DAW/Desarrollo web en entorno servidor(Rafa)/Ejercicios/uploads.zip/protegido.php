<?php // public/protegido.php
declare(strict_types=1);
session_start();
if (empty($_SESSION['usuario'])) {
  header('Location: sesiones_login.php');
  exit;
}
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Protegido</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Página protegida</h1></header><section>
<p>Hola, <strong><?= htmlspecialchars($_SESSION['usuario']) ?></strong>. Solo usuarios logueados pueden ver esto.</p>
<p><a href="sesiones_login.php">Volver</a></p>
</section></body></html>
