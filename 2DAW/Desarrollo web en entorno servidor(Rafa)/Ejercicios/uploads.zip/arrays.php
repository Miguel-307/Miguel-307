<?php // public/arrays.php
declare(strict_types=1);
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Arrays – Alto Orden</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>Arrays de orden superior</h1></header><section>

<article>
<h3>array_walk (iterar)</h3>
<pre><?php
$nums = [1,2,3,4];
array_walk($nums, function($valor, $indice){
  echo "Índice $indice => $valor\n";
});
?></pre>
</article>

<article>
<h3>array_filter (filtrar)</h3>
<pre><?php
$pares = array_filter($nums, fn($n)=> $n % 2 === 0);
print_r($pares); // [1=>2, 3=>4]
?></pre>
</article>

<article>
<h3>array_map (modificar)</h3>
<pre><?php
$porTres = array_map(fn($n)=> $n*3, $nums);
print_r($porTres); // [3,6,9,12]
?></pre>
</article>

<article>
<h3>array_reduce (calcular)</h3>
<pre><?php
$suma = array_reduce($nums, fn($acc,$n)=> $acc+$n, 0);
echo "Suma: $suma\n"; // 10
?></pre>
</article>

<p><a href="index.php">Volver</a></p>
</section></body></html>
