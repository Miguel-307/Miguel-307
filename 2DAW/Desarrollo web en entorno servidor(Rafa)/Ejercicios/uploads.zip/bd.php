<?php // public/db.php
declare(strict_types=1);
?>
<!DOCTYPE html><html lang="es"><head>
<meta charset="UTF-8"><title>Base de Datos (PDO)</title><link rel="stylesheet" href="estilos.css">
</head><body><header><h1>PDO: conexión y consultas</h1></header><section>
<article><pre><?php
$dsn = 'mysql:host=localhost;dbname=demo;charset=utf8mb4';
$user = 'demo_user';
$pass = 'demo_pass';

try {
  $pdo = new PDO($dsn, $user, $pass, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);

  // Crear tabla si no existe
  $pdo->exec("
    CREATE TABLE IF NOT EXISTS usuarios (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(120) UNIQUE NOT NULL,
      pass_hash VARCHAR(255) NOT NULL,
      creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  ");

  // Insert con contraseña segura
  $email = 'miguel@example.com';
  $hash = password_hash('Secreta123', PASSWORD_BCRYPT);

  $ins = $pdo->prepare("INSERT IGNORE INTO usuarios (email, pass_hash) VALUES (?, ?)");
  $ins->execute([$email, $hash]);

  echo "Usuario insertado/ignorado si ya existe.\n";

  // Login: verificar
  $emailLogin = 'miguel@example.com';
  $passLogin  = 'Secreta123';

  $sel = $pdo->prepare("SELECT pass_hash FROM usuarios WHERE email = ?");
  $sel->execute([$emailLogin]);
  $row = $sel->fetch();

  if ($row && password_verify($passLogin, $row['pass_hash'])) {
    echo "Login OK\n";
  } else {
    echo "Login FAIL\n";
  }

} catch (Throwable $e) {
  echo "Error PDO: ".$e->getMessage();
}
?></pre></article>

<details>
  <summary>Nota sobre SHA1</summary>
  <p><code>sha1()</code> y <code>sha1_file()</code> son útiles para huellas de archivos/integridad. Para contraseñas, usa <code>password_hash()</code>/<code>password_verify()</code>.</p>
</details>

<p><a href="index.php">Volver</a></p>
</section></body></html>
