<?php // public/index.php
declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Playground PHP – Índice</title>
  <link rel="stylesheet" href="estilos.css">
</head>
<body>
<header>
  <h1>Playground PHP</h1>
  <p>Ejemplos básicos y avanzados en módulos separados.</p>
</header>

<nav class="grid">
  <a href="funciones.php">Funciones (parámetros, return, anónimas, externas)</a>
  <a href="arrays.php">array_walk / array_filter / array_map / array_reduce</a>
  <a href="upload.php">Ficheros (subir, SHA1, tamaño) + borrar</a>
  <a href="mail_plain.php">Enviar email (texto plano) + SMTP</a>
  <a href="mail_html_phpmailer.php">Email HTML con PHPMailer (SMTP)</a>
  <a href="sesiones_login.php">Sesiones + login + página protegida</a>
  <a href="cookies.php">Cookies: crear/obtener/actualizar/borrar</a>
  <a href="poo.php">POO: clase, constructor, visibilidad, herencia</a>
  <a href="db.php">Base de datos (PDO, consultas preparadas)</a>
</nav>

<section>
  <h2>GET vs POST (method + action)</h2>

  <article>
    <h3>Ejemplo GET (datos visibles en la URL)</h3>
    <form method="GET" action="index.php">
      <label>Tu nombre: <input name="nombre" required></label>
      <button>Enviar (GET)</button>
    </form>
    <?php if (!empty($_GET['nombre'])): ?>
      <p><strong>GET recibido:</strong> <?= htmlspecialchars($_GET['nombre']) ?></p>
    <?php endif; ?>
  </article>

  <article>
    <h3>Ejemplo POST (datos en el cuerpo de la petición)</h3>
    <form method="POST" action="index.php">
      <label>Tu email: <input type="email" name="email" required></label>
      <button>Enviar (POST)</button>
    </form>
    <?php if (!empty($_POST['email'])): ?>
      <p><strong>POST recibido:</strong> <?= htmlspecialchars($_POST['email']) ?></p>
    <?php endif; ?>
  </article>

  <details>
    <summary>Notas rápidas</summary>
    <ul>
      <li><code>method="GET"</code> → datos en la URL. Ideal para búsquedas o enlaces compartibles.</li>
      <li><code>method="POST"</code> → datos en el cuerpo. Ideal para formularios con datos sensibles.</li>
      <li><code>action="archivo.php"</code> → a qué script se envía el formulario. Si lo omites, se envía a la misma página.</li>
    </ul>
  </details>
</section>
</body>
</html>
