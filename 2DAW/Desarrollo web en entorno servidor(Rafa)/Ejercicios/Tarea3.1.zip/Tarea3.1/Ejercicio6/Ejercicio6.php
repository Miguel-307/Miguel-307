<?php
$usuario_valido = "miguel";
$password_valido = "12345";
$usuario = "";
$mensaje = "";


if(isset($_POST['usuario']) && isset($_POST['password'])){
    if($_POST['usuario'] == $usuario_valido && $_POST['password'] == $password_valido){
        $usuario = $_POST['usuario']; 
    } else {
        $mensaje = "Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login sencillo</title>
</head>
<body>

<?php if($usuario != ""): ?>

        Usuario: <?php echo $usuario; ?>

        <h2>¡Bienvenido, <?php echo $usuario; ?>!</h2>
        <p>Has iniciado sesión correctamente.</p>

<?php else: ?>
        <h2>Iniciar sesión</h2>
        <?php if($mensaje != "") echo "<p class='error'>$mensaje</p>"; ?>
        <form method="post" action="">
            <label>Usuario:</label><br>
            <input type="text" name="usuario" required><br><br>
            <label>Contraseña:</label><br>
            <input type="password" name="password" required><br><br>
            <input type="submit" value="Entrar">

<?php endif; ?>
               <nav>
        <a href="/php/ejemplo.php">Volver a Inicio</a>
    </nav>

</body>
</html>
