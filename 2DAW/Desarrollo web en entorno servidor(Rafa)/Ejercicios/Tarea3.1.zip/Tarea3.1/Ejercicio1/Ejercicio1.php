<?php
$nombre = $_POST['nombre']; 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Página 2</title>
</head>
<body>
    <h1>Texto introducido:</h1>
    <p><?php echo $nombre; ?></p>

        <nav>
        <a href="Ejercicio1.html">Volver al html</a>
    </nav>
</body>

