<?php
// Recibir el dato del formulario
$pixeles = $_POST['pixeles'] ?? 0; // si no existe, 0
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
    <style>
        div {
            width: <?php echo $pixeles; ?>px;
            height: <?php echo $pixeles; ?>px;
            background-color: black;
        }
        nav a {
            text-decoration: none;
            color: #007BFF;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <h1>Resultado</h1>
    <?php if ($pixeles > 0): ?>
        <div></div>
    <?php else: ?>
        <p>No introdujiste un tamaño válido.</p>
    <?php endif; ?>

    <nav>
        <a href="Ejercicio2.html">Volver al inicio</a>
    </nav>
</body>
</html>
