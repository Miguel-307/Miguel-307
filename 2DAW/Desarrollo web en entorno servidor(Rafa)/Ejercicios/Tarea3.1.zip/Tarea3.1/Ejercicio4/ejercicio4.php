<?php
$fruta = $_POST['fruta'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio4</title>
        <style>
                nav a {
            text-decoration: none;
            color: #007BFF;
            radius: 5px;
            font-size: 18px;
        }
    </style>
</head>
<body>
  <h1>Tu fruta favorita es:</h1>

    <?php if ($fruta): ?>
        <p><?php echo htmlspecialchars($fruta, ENT_QUOTES, 'UTF-8'); ?></p>
    <?php else: ?>
        <p>No seleccionaste ninguna fruta.</p>
    <?php endif; ?>

    <p><a href="Ejercicio4.html">Volver a elegir</a></p>
</body>
</html>