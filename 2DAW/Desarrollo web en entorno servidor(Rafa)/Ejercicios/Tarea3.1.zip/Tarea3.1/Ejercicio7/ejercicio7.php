<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio7</title>
    <style>
                nav a {
            text-decoration: none;
            color: #007BFF;
            radius: 5px;
            font-size: 18px;
        }
    </style>
</head>
<body>
      <h1>Subir un archivo al servidor</h1>

    <form action="ejercicio7.php" method="post" enctype="multipart/form-data">
        <label>Selecciona un archivo:</label><br>
        <input type="file" name="archivo" required><br><br>
        <input type="submit" name="enviar" value="Subir">
    </form>

    <?php
    if(isset($_POST['enviar'])){
        $carpeta = "Subidas/";
        $nombreArchivo = basename($_FILES['archivo']['name']);
        $rutaDestino = $carpeta . $nombreArchivo;

        
        if(move_uploaded_file($_FILES['archivo']['tmp_name'], $rutaDestino)){
            echo "<p class='mensaje'>El archivo '$nombreArchivo' se ha subido correctamente.</p>";
        } else {
            echo "<p class='error'>Error al subir el archivo.</p>";
        }
    }
    ?>
    <nav>
        <a href="/php/ejemplo.php">Volver a Inicio</a>
    </nav>
</body>
</html>