<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio5</title>
        <style>
             a {
            text-decoration: none;
            color: #007BFF;
            radius: 5px;
            font-size: 18px;
        }
    </style>
</head>
<body>
 <?php
    if(isset($_POST['fruta'])) {
        $fruta = $_POST['fruta'];
        echo "<h1>Tu fruta favorita es: $fruta</h1>";

        switch($fruta) {
            case "Manzana":
                echo '<img src="imagenes/manzana.png" alt="Manzana" width="200">';
                break;
            case "pera":
                echo '<img src="imagenes/pera.png" alt="Plátano" width="200">';
                break;
            case "Fresa":
                echo '<img src="imagenes/fresa.png" alt="Fresa" width="200">';
                break;
            default:
                echo "<p>No se ha seleccionado ninguna fruta válida.</p>";
        }
    } else {
        echo "<p>No se ha enviado ninguna fruta.</p>";
    }
    ?>
    <br><br>
    <a href="ejercicio5.html">Volver a elegir</a>
</body>
</html>