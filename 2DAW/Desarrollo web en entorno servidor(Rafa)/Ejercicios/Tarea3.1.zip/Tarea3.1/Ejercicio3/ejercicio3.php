
<?php
$tamano = $_POST['tamano'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio3</title>
        <style>
                nav a {
            text-decoration: none;
            color: #007BFF;
            radius: 5px;
            font-size: 18px;
        }
                .cuadrado {
            width: <?php echo $tamano; ?>px;
            height: <?php echo $tamano; ?>px;
            background-color: white;     
            border: 4px solid black;     
            margin: 20px auto;           
        }
    </style>
</head>
<body>
        <h1>Resultado</h1>

    <?php if ($tamano > 0): ?>
        <div class="cuadrado"></div>
    <?php else: ?>
        <p>No introdujiste un tamaño válido.</p>
    <?php endif; ?>

    <p><a href="ejercicio3.html">Volver al formulario</a></p>
    <nav>
        <a href="/php/ejemplo.php">Volver a Inicio</a>
    </nav>
</body>
</html>
