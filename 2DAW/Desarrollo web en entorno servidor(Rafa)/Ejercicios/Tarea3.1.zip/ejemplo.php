<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarea3.1</title>
        <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        nav a {
            text-decoration: none;
            color: #007BFF;
            radius: 5px;
            font-size: 18px;
        }
 
        </style>
</head>
<body>
    <h1>Bienvenido a la Tarea 3.1</h1>
    <nav>
        <a href="Tarea3.1/Ejercicio1/Ejercicio1.html">Ejercicio1</a> <br><br>
        <a href="Tarea3.1/Ejercicio2/Ejercicio2.html">Ejercicio2</a> <br><br>
        <a href="Tarea3.1/Ejercicio3/Ejercicio3.html">Ejercicio3</a><br><br>
        <a href="Tarea3.1/Ejercicio4/Ejercicio4.html">Ejercicio4</a> <br><br>
        <a href="Tarea3.1/Ejercicio5/Ejercicio5.html">Ejercicio5</a> <br><br>
        <a href="Tarea3.1/Ejercicio6/Ejercicio6.php">Ejercicio6</a><br><br>
        <a href="Tarea3.1/Ejercicio7/Ejercicio7.php">Ejercicio7</a><br><br>
    </nav>
</body>
</html>