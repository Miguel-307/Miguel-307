<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Conexión con PDO</title>

</head>
<body>
  <h1>Conexión con PDO</h1>
  

  <form method="post">
    <label>Servidor:</label>
    <input type="text" name="servidor" required placeholder="Ej: localhost">

    <label>Base de datos:</label>
    <input type="text" name="basedatos" required placeholder="Ej: test">

    <label>Usuario:</label>
    <input type="text" name="usuario" required placeholder="Ej: root">

    <label>Contraseña:</label>
    <input type="password" name="clave" placeholder="(vacío si no hay)">

    <button type="submit" name="conectar">Conectar</button>
  </form>

  <?php
 
  if (isset($_POST['conectar'])) {
  
      $servidor = $_POST['servidor'];
      $basedatos = $_POST['basedatos'];
      $usuario = $_POST['usuario'];
      $clave = $_POST['clave'];

      echo "<div class='resultado'>";
      try {
        
          $dsn = "mysql:host=$servidor;dbname=$basedatos;charset=utf8";

          $conexion = new PDO($dsn, $usuario, $clave);

       
          $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          echo " Conexión exitosa a la base de datos <b>$basedatos</b> usando PDO.";
      } catch (PDOException $e) {
        
          echo " Error al conectar con PDO:<br>" . $e->getMessage();
      }
      echo "</div>";
  }
  ?>
</body>
</html>
