<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Conexión con MySQLi</title>
 
</head>
<body>
  <h1>Conexión con MySQLi</h1>
  
  <form method="post">
    <label>Servidor:</label>
    <input type="text" name="servidor" required placeholder="Ej: localhost">

    <label>Base de datos:</label>
    <input type="text" name="basedatos" required placeholder="Ej: test">

    <label>Usuario:</label>
    <input type="text" name="usuario" required placeholder="Ej: root">

    <label>Contraseña:</label>
    <input type="password" name="clave" placeholder="(vacío si no hay)">

    <button type="submit" name="conectar">Conectar</button>
  </form>

  <?php
 
  if (isset($_POST['conectar'])) {

      $servidor = $_POST['servidor'];
      $basedatos = $_POST['basedatos'];
      $usuario = $_POST['usuario'];
      $clave = $_POST['clave'];

  
      $conexion = @new mysqli($servidor, $usuario, $clave, $basedatos);

      echo "<div class='resultado'>";
      if ($conexion->connect_error) {

          echo " Error al conectar con MySQLi:<br>" . $conexion->connect_error;
      } else {

          echo " Conexión exitosa a la base de datos <b>$basedatos</b> usando MySQLi.";
          $conexion->close();
      }
      echo "</div>";
  }
  ?>
</body>
</html>
